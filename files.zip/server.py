# Cake Cafe - table manager. Run: python server.py  (no installs needed)
import json, os, time, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

PORT = int(os.environ.get("PORT", 8000))
DB = "data.json"
# PIN -> [name, can_edit]   (غيّر الأسماء والأرقام هنا)
USERS = {
    "1111": ["ليدر شيفت", True],
    "2222": ["مساعد المدير", True],
    "3333": ["المدير", True],
    "0000": ["موظف", False],
}
lock = threading.Lock()

def new_table(i, zone, active=True):
    return {"id": str(i), "zone": zone, "active": active, "status": "free", "people": 0,
            "name": "", "at": "", "since": 0, "merged": None, "from": None}

def init():
    T = {}
    for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, 38]: T[str(i)] = new_table(i, "indoor")
    T["ht3"] = new_table("ht3", "indoor", False)
    for i in list(range(10, 32)) + [46, 47]: T[str(i)] = new_table(i, "outdoor")
    for i in [35, 37]: T[str(i)] = new_table(i, "outdoor", False)
    return {"tables": T, "wait": [], "log": [], "wid": 0}

S = json.load(open(DB, encoding="utf-8")) if os.path.exists(DB) else init()

def save():
    json.dump(S, open(DB, "w", encoding="utf-8"), ensure_ascii=False)

def reset(t):
    t.update(status="free", people=0, name="", at="", since=0, merged=None)

def act(who, a):
    T, d = S["tables"], a.get("do")
    t = T.get(str(a.get("id")))
    if d == "wait_add":
        S["wid"] += 1
        S["wait"].append({"wid": S["wid"], "name": a["name"], "people": int(a["people"]), "since": time.time()})
        return f"أضاف {a['name']} ({a['people']} أفراد) لقائمة الانتظار"
    if d == "wait_del":
        S["wait"] = [w for w in S["wait"] if w["wid"] != a["wid"]]
        return "شال اسم من قائمة الانتظار"
    if d == "wait_seat":
        w = next(w for w in S["wait"] if w["wid"] == a["wid"])
        if t["status"] != "free": return None
        t.update(status="occupied", people=w["people"], name=w["name"], since=time.time())
        S["wait"].remove(w)
        return f"أجلس {w['name']} من الانتظار على ترابيزة {t['id']}"
    if d == "add":
        i = str(a["newid"])
        if i in T: return None
        T[i] = new_table(i, a["zone"])
        return f"زوّد ترابيزة {i}"
    if not t: return None
    n = t["id"]
    if d == "seat":
        if t["status"] not in ("free", "reserved"): return None
        t.update(status="occupied", people=int(a["people"]), since=time.time())
        return f"فتح ترابيزة {n} ({t['people']} أفراد)"
    if d == "reserve":
        if t["status"] != "free": return None
        t.update(status="reserved", name=a["name"], at=a["at"])
        return f"حجز ترابيزة {n} باسم {a['name']}" + (f" الساعة {a['at']}" if a.get("at") else "")
    if d == "bill":
        t["status"] = "bill"; return f"ترابيزة {n} طلبت الحساب"
    if d == "paid":
        t["status"] = "paid"; return f"ترابيزة {n} اتحاسبت"
    if d == "free":
        for c in T.values():
            if c["merged"] == n: reset(c)
        reset(t); return f"فضّى ترابيزة {n}"
    if d == "transfer":
        to = T.get(str(a["to"]))
        if not to or to["status"] != "free" or not to["active"]: return None
        for k in ("status", "people", "name", "at", "since"): to[k] = t[k]
        for c in T.values():
            if c["merged"] == n: c["merged"] = to["id"]
        reset(t); return f"نقل ترابيزة {n} إلى {to['id']}"
    if d == "merge":
        o = T.get(str(a["with"]))
        if not o or o["status"] != "free" or o is t: return None
        o.update(status="merged", merged=n); return f"ضم ترابيزة {o['id']} مع {n}"
    if d == "unmerge":
        reset(t); return f"فك دمج ترابيزة {n}"
    if d == "enable":
        if t["active"]: return None
        t["active"] = True; t["from"] = str(a.get("from") or "")
        return f"فصل ترابيزة {a['from']} وظهرت ترابيزة {n}" if a.get("from") else f"فعّل ترابيزة {n}"
    if d == "disable":
        if t["status"] != "free": return None
        t["active"] = False; src = t["from"]; t["from"] = None
        return f"رجّع ترابيزة {n}" + (f" لـ {src}" if src else "")
    return None

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == "/api/state":
            with lock: return self.send(200, S)
        self.send(200, open("index.html", "rb").read(), "text/html")
    def do_POST(self):
        a = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        pin = str(a.get("pin", "")).strip().translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789"))
        u = USERS.get(pin)
        if not u: return self.send(403, {"error": "PIN غلط"})
        if self.path == "/api/login": return self.send(200, {"name": u[0], "edit": u[1]})
        if not u[1]: return self.send(403, {"error": "مش مسموح"})
        with lock:
            try: msg = act(u[0], a)
            except Exception: msg = None
            if msg:
                S["log"].append({"t": time.time(), "who": u[0], "msg": msg}); S["log"] = S["log"][-200:]; save()
            self.send(200 if msg else 409, {"ok": bool(msg)})

if __name__ == "__main__":
    print(f"Cake Cafe شغال على http://localhost:{PORT}")
    ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()
